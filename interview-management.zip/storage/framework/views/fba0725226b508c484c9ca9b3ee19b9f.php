<div>
   <!-- resources/views/livewire/header.blade.php -->
<div class="header" style="background: #f8f9fa; padding: 1rem;">
    <nav>
        <button wire:click = 'transferUserSetting'>設定</button>
        <button wire:click = 'logout'>ログアウト</button>
        <span>こんにちは, <?php echo e($name); ?> さん</span>
    </nav>
</div>

</div>
<?php /**PATH /var/www/html/resources/views/livewire/header.blade.php ENDPATH**/ ?>