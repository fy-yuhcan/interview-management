<div>
    <!-- Google ログインボタン -->
    <button wire:click="loginGoogle" class="btn btn-primary">
        Googleでログイン
    </button>
</div>
<?php /**PATH /var/www/html/resources/views/livewire/oauth-login.blade.php ENDPATH**/ ?>