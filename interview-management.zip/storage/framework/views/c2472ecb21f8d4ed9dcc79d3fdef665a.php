<div>
    <h2>カレンダー</h2>

    <table border="1" style="border-collapse: collapse; width: 100%;">
        <thead>
            <tr>
                <th>時間</th>
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $weekDates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <th style="min-width: 150px;">
                    <?php echo e($day->format('m/d (D)')); ?>

                </th>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                
            </tr>
        </thead>
        <tbody>
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $dayHours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hour): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td style="text-align: center;">
                    <?php echo e(str_pad($hour, 2, '0', STR_PAD_LEFT)); ?>:00
                </td>
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $weekDates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                $dateKey = $day->format('Y-m-d');
                $hourKey = str_pad($hour, 2, '0', STR_PAD_LEFT);
            
                $hourEvents = $eventsDayHour[$dateKey][$hourKey] ?? [];
                ?>
                <td style="vertical-align: top;">
                    <!--[if BLOCK]><![endif]--><?php if(count($hourEvents) > 0): ?>
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $hourEvents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('events.show', ['event_id' => $event->id])); ?>">
                        <strong>タイトル:</strong> <?php echo e($event->title); ?><br>
                        <strong>開始:</strong> <?php echo e($event->start_time->format('H:i')); ?>

                    </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
        </tbody>
    </table>
</div><?php /**PATH /var/www/html/resources/views/livewire/calendar.blade.php ENDPATH**/ ?>