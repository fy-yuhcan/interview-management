<div>
    <h1>ユーザー設定</h1>

    <!--[if BLOCK]><![endif]--><?php if(session()->has('message')): ?>
    <div style="color: green;">
        <?php echo e(session('message')); ?>

    </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <form wire:submit.prevent="updateEmail">
        <div>
            <label>メールアドレス:</label>
            <input type="email" wire:model="email" placeholder="<?php echo e($user->email); ?>">
        </div>

        <button type="submit">更新</button>
    </form>
</div><?php /**PATH /var/www/html/resources/views/livewire/user-setting.blade.php ENDPATH**/ ?>