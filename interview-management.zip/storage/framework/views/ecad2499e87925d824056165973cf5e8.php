<div>
    <form wire:submit.prevent="submit">
        <textarea wire:model="prompt" placeholder="イベントの内容を入力してください"></textarea>
        <button type="submit">イベント作成</button>
    </form>

    <!--[if BLOCK]><![endif]--><?php if(session()->has('message')): ?>
    <div style="color: green;"><?php echo e(session('message')); ?></div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <?php if(session()->has('error')): ?>
    <div style="color: red;"><?php echo e(session('error')); ?></div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH /var/www/html/resources/views/livewire/input.blade.php ENDPATH**/ ?>