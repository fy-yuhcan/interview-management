<div>
    <!-- Google ログインボタン -->
    <button wire:click="loginGoogle" class="btn btn-primary">
        Googleでログイン
    </button>
</div>
